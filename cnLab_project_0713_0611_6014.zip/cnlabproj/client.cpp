#include <iostream>
#include <string>
#include <thread>
#include <mutex>
#include <vector>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <chrono>

#define SERVER_IP "127.0.0.1"
#define TCP_PORT 8080
#define UDP_PORT 8081
#define UDP_BASE_PORT 9000
#define BUFFER_SIZE 4096

using namespace std;

string campusName;
string campusPassword;
int tcpSocket;
int udpSocket;
int udpListenPort;
mutex coutMutex;
bool isConnected = false;
vector<string> inboxMessages;

// Thread-safe console output
void safePrint(const string& message) {
    lock_guard<mutex> lock(coutMutex);
    cout << message << endl;
}

// Listen for incoming TCP messages from server
void receiveTCPMessages() {
    char buffer[BUFFER_SIZE];

    while (isConnected) {
        memset(buffer, 0, BUFFER_SIZE);
        int bytesReceived = recv(tcpSocket, buffer, BUFFER_SIZE - 1, 0);

        if (bytesReceived <= 0) {
            safePrint("\n[ERROR] Connection to server lost!");
            isConnected = false;
            break;
        }

        string message(buffer);

        if (message.find("ERROR:") == 0) {
            safePrint("\n[SERVER ERROR] " + message.substr(6));
        } else {
            size_t fromPos = message.find("FROM:");
            size_t deptPos = message.find("|DEPT:");
            size_t msgPos = message.find("|MSG:");

            if (fromPos != string::npos && deptPos != string::npos && msgPos != string::npos) {
                string fromCampus = message.substr(fromPos + 5, deptPos - fromPos - 5);
                string department = message.substr(deptPos + 6, msgPos - deptPos - 6);
                string actualMessage = message.substr(msgPos + 5);

                string formattedMsg;
                formattedMsg += "\n╔════════════════════════════════════════╗\n";
                formattedMsg += "║         NEW MESSAGE RECEIVED           ║\n";
                formattedMsg += "╠════════════════════════════════════════╣\n";
                formattedMsg += "║ From Campus: " + fromCampus +"                    ║\n";
                formattedMsg += "║ Department: " + department +"                         ║\n";
                formattedMsg += "║ Message: " + actualMessage +"                           ║\n";
                formattedMsg += "╚════════════════════════════════════════╝\n";

                safePrint(formattedMsg);

                lock_guard<mutex> lock(coutMutex);
                inboxMessages.push_back(formattedMsg);
            }
        }
    }
}

// Send UDP heartbeat status to server
void sendHeartbeat() {
    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(UDP_PORT);
    inet_pton(AF_INET, SERVER_IP, &serverAddr.sin_addr);

    while (isConnected) {
        string statusMsg = "STATUS:" + campusName + ":Online:" + to_string(udpListenPort);
        sendto(udpSocket, statusMsg.c_str(), statusMsg.length(), 0,
               (struct sockaddr*)&serverAddr, sizeof(serverAddr));
        this_thread::sleep_for(chrono::seconds(10));
    }
}

// Listen for UDP broadcasts from server
void receiveUDPBroadcasts() {
    int udpListenSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (udpListenSocket < 0) {
        safePrint("[ERROR] Failed to create UDP listen socket");
        return;
    }

    int opt = 1;
    setsockopt(udpListenSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in listenAddr;
    listenAddr.sin_family = AF_INET;
    listenAddr.sin_addr.s_addr = INADDR_ANY;
    listenAddr.sin_port = htons(udpListenPort);

    int attempts = 0;
    while (bind(udpListenSocket, (struct sockaddr*)&listenAddr, sizeof(listenAddr)) < 0 && attempts < 10) {
        udpListenPort++;
        listenAddr.sin_port = htons(udpListenPort);
        attempts++;
    }

    if (attempts >= 10) {
        safePrint("[ERROR] Failed to bind UDP listen socket after 10 attempts");
        close(udpListenSocket);
        return;
    }

    safePrint("[INFO] UDP listening on port " + to_string(udpListenPort));

    char buffer[BUFFER_SIZE];
    struct sockaddr_in serverAddr;
    socklen_t serverLen = sizeof(serverAddr);

    while (isConnected) {
        memset(buffer, 0, BUFFER_SIZE);
        int bytesReceived = recvfrom(udpListenSocket, buffer, BUFFER_SIZE - 1, 0,
                                     (struct sockaddr*)&serverAddr, &serverLen);

        if (bytesReceived > 0) {
            string message(buffer);
            if (message.find("BROADCAST:") == 0) {
                string announcement = message.substr(10);
                safePrint("\n╔════════════════════════════════════════╗");
                safePrint("║      SYSTEM-WIDE ANNOUNCEMENT          ║");
                safePrint("╠════════════════════════════════════════╣");
                safePrint("║ " + announcement);                    
                safePrint("╚════════════════════════════════════════╝\n");
            }
        }
    }

    close(udpListenSocket);
}

// Display message inbox
void viewInbox() {
    lock_guard<mutex> lock(coutMutex);
    if (inboxMessages.empty()) {
        cout << "\n[INFO] No messages received yet.\n";
        return;
    }

    cout << "\n==================== RECEIVED MESSAGES ====================\n";
    for (const auto& msg : inboxMessages) {
        cout << msg << endl;
    }
    cout << "===========================================================\n";
}

// Display main menu and handle user interaction
void displayMenu() {
    while (isConnected) {
        cout << "\n╔════════════════════════════════════════╗" << endl;
        cout << "║   NU-Information Exchange System       ║" << endl;
        cout << "║   Campus:" << campusName << string(30 - campusName.length(), ' ') << "║" << endl;
        cout << "╠════════════════════════════════════════╣" << endl;
        cout << "║ 1. Send Message to Another Campus      ║" << endl;
        cout << "║ 2. View Received Messages              ║" << endl;
        cout << "║ 3. View Connection Status              ║" << endl;
        cout << "║ 4. Exit                                ║" << endl;
        cout << "╚════════════════════════════════════════╝" << endl;
        cout << "Enter your choice: ";

        int choice;
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            viewInbox();

            cout << "\nAvailable Campuses: Islamabad, Lahore, Karachi, Peshawar, Multan, CFD" << endl;
            cout << "Enter target campus name: ";
            string targetCampus;
            getline(cin, targetCampus);

            cout << "Available Departments: Admissions, Academics, IT, Sports" << endl;
            cout << "Enter target department: ";
            string targetDept;
            getline(cin, targetDept);

            cout << "Enter your message: ";
            string message;
            getline(cin, message);

            string formattedMsg = "TO:" + targetCampus + "|DEPT:" + targetDept + "|MSG:" + message;

            send(tcpSocket, formattedMsg.c_str(), formattedMsg.length(), 0);
            cout << "\n[SUCCESS] Message sent to " << targetCampus << " (" << targetDept << ")" << endl;
        }
        else if (choice == 2) {
            viewInbox();
        }
        else if (choice == 3) {
            cout << "\n╔════════════════════════════════════════╗" << endl;
            cout << "║        Connection Status               ║" << endl;
            cout << "╠════════════════════════════════════════╣" << endl;
            cout << "║ Campus: " << campusName << "                         ║" << endl;
            cout << "║ Status: Connected to Central Server    ║" << endl;
            cout << "║ TCP: Active                            ║" << endl;
            cout << "║ UDP Heartbeat: Active                  ║" << endl;
            cout << "║ UDP Listen Port: " << udpListenPort << "                  ║" << endl;
            cout << "╚════════════════════════════════════════╝" << endl;
        }
        else if (choice == 4) {
            cout << "\nDisconnecting from server..." << endl;
            isConnected = false;
            close(tcpSocket);
            close(udpSocket);
            cout << "Goodbye!" << endl;
            exit(0);
        }
        else {
            cout << "\n[ERROR] Invalid choice. Please try again." << endl;
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cout << "Usage: ./client <CampusName> <Password>" << endl;
        cout << "Example: ./client Lahore NU-LHR-123" << endl;
        return 1;
    }

    campusName = argv[1];
    campusPassword = argv[2];

    int portOffset = 0;
    for (char c : campusName) portOffset += c;
    udpListenPort = UDP_BASE_PORT + (portOffset % 100);

    tcpSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (tcpSocket < 0) {
        cerr << "Failed to create TCP socket" << endl;
        return 1;
    }

    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(TCP_PORT);
    inet_pton(AF_INET, SERVER_IP, &serverAddr.sin_addr);

    cout << "Connecting to Central Server..." << endl;
    if (connect(tcpSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        cerr << "Failed to connect to server" << endl;
        return 1;
    }

    string authMsg = "Campus:" + campusName + ",Pass:" + campusPassword;
    send(tcpSocket, authMsg.c_str(), authMsg.length(), 0);

    char buffer[BUFFER_SIZE];
    memset(buffer, 0, BUFFER_SIZE);
    recv(tcpSocket, buffer, BUFFER_SIZE - 1, 0);

    string response(buffer);
    if (response == "AUTH_SUCCESS") {
        cout << "\n╔════════════════════════════════════════╗" << endl;
        cout << "║   Authentication Successful!           ║" << endl;
        cout << "║   Connected to Central Server          ║" << endl;
        cout << "╚════════════════════════════════════════╝\n" << endl;

        isConnected = true;
        udpSocket = socket(AF_INET, SOCK_DGRAM, 0);

        thread tcpReceiveThread(receiveTCPMessages); tcpReceiveThread.detach();
        thread udpHeartbeatThread(sendHeartbeat); udpHeartbeatThread.detach();
        thread udpBroadcastThread(receiveUDPBroadcasts); udpBroadcastThread.detach();

        sleep(1);
        displayMenu();
    } else {
        cout << "\n[ERROR] Authentication failed! Invalid campus name or password." << endl;
        close(tcpSocket);
        return 1;
    }

    return 0;
}

