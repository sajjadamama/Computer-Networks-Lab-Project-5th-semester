#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <thread>
#include <mutex>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define TCP_PORT 8080
#define UDP_PORT 8081
#define BUFFER_SIZE 4096

using namespace std;

// Structure to hold client information
struct CampusClient {
    int tcpSocket;
    string campusName;
    string lastStatus;
    time_t lastSeen;
    int udpPort;
    string ipAddress;
};

// Global data structures
map<string, CampusClient> connectedClients; // campusName -> client info
mutex clientsMutex;
mutex coutMutex;

// Thread-safe console output
void safePrint(const string& message) {
    lock_guard<mutex> lock(coutMutex);
    cout << message << endl;
}

// Validate campus credentials
bool authenticateClient(const string& authMessage, string& campusName) {
    // Expected format: "Campus:Lahore,Pass:NU-LHR-123"
    size_t campusPos = authMessage.find("Campus:");
    size_t passPos = authMessage.find(",Pass:");
   
    if (campusPos == string::npos || passPos == string::npos) {
        return false;
    }
   
    campusName = authMessage.substr(campusPos + 7, passPos - campusPos - 7);
    string password = authMessage.substr(passPos + 6);
   
    // Hard-coded credentials for different campuses
    map<string, string> validCredentials = {
        {"Islamabad", "NU-ISB-123"},
        {"Lahore", "NU-LHR-123"},
        {"Karachi", "NU-KHI-123"},
        {"Peshawar", "NU-PSH-123"},
        {"Multan", "NU-MLT-123"},
        {"CFD", "NU-CFD-123"}
    };
   
    if (validCredentials.find(campusName) != validCredentials.end() &&
        validCredentials[campusName] == password) {
        return true;
    }
   
    return false;
}

// Handle individual campus client communication
void handleCampusClient(int clientSocket, string campusName) {
    char buffer[BUFFER_SIZE];
   
    while (true) {
        memset(buffer, 0, BUFFER_SIZE);
        int bytesReceived = recv(clientSocket, buffer, BUFFER_SIZE - 1, 0);
       
        if (bytesReceived <= 0) {
            safePrint("[SERVER] Campus " + campusName + " disconnected.");
           
            // Remove from connected clients
            {
                lock_guard<mutex> lock(clientsMutex);
                connectedClients.erase(campusName);
            }
           
            close(clientSocket);
            return;
        }
       
        string message(buffer);
        safePrint("[SERVER] Received from " + campusName + ": " + message);
       
        // Parse message format: "TO:TargetCampus|DEPT:TargetDept|MSG:ActualMessage"
        size_t toPos = message.find("TO:");
        size_t deptPos = message.find("|DEPT:");
        size_t msgPos = message.find("|MSG:");
       
        if (toPos != string::npos && deptPos != string::npos && msgPos != string::npos) {
            string targetCampus = message.substr(toPos + 3, deptPos - toPos - 3);
            string targetDept = message.substr(deptPos + 6, msgPos - deptPos - 6);
            string actualMessage = message.substr(msgPos + 5);
           
            // Route message to target campus
            {
                lock_guard<mutex> lock(clientsMutex);
                if (connectedClients.find(targetCampus) != connectedClients.end()) {
                    string forwardMsg = "FROM:" + campusName + "|DEPT:" + targetDept + "|MSG:" + actualMessage;
                    send(connectedClients[targetCampus].tcpSocket, forwardMsg.c_str(), forwardMsg.length(), 0);
                    safePrint("[SERVER] Routed message from " + campusName + " to " + targetCampus);
                } else {
                    string errorMsg = "ERROR:Campus " + targetCampus + " is not online.";
                    send(clientSocket, errorMsg.c_str(), errorMsg.length(), 0);
                    safePrint("[SERVER] Failed to route: " + targetCampus + " is offline.");
                }
            }
        }
    }
}

// Handle UDP status updates
void handleUDPStatus(int udpSocket) {
    struct sockaddr_in clientAddr;
    socklen_t clientLen = sizeof(clientAddr);
    char buffer[BUFFER_SIZE];
   
    while (true) {
        memset(buffer, 0, BUFFER_SIZE);
        int bytesReceived = recvfrom(udpSocket, buffer, BUFFER_SIZE - 1, 0,
                                     (struct sockaddr*)&clientAddr, &clientLen);
       
        if (bytesReceived > 0) {
            string statusMsg(buffer);
            // Expected format: "STATUS:CampusName:Online:UDPPort"
            size_t pos1 = statusMsg.find(":");
            size_t pos2 = statusMsg.find(":", pos1 + 1);
            size_t pos3 = statusMsg.find(":", pos2 + 1);
           
            if (pos1 != string::npos && pos2 != string::npos) {
                string campusName = statusMsg.substr(pos1 + 1, pos2 - pos1 - 1);
                string status = statusMsg.substr(pos2 + 1, pos3 - pos2 - 1);
                int clientPort = 0;
                if (pos3 != string::npos) {
                    clientPort = stoi(statusMsg.substr(pos3 + 1));
                }
               
                lock_guard<mutex> lock(clientsMutex);
                if (connectedClients.find(campusName) != connectedClients.end()) {
                    connectedClients[campusName].lastStatus = status;
                    connectedClients[campusName].lastSeen = time(nullptr);
                    connectedClients[campusName].udpPort = clientPort;
                   
                    // Store client IP address
                    char clientIP[INET_ADDRSTRLEN];
                    inet_ntop(AF_INET, &(clientAddr.sin_addr), clientIP, INET_ADDRSTRLEN);
                    connectedClients[campusName].ipAddress = string(clientIP);
                   
                    safePrint("[UDP] Status update from " + campusName + ": " + status);
                }
            }
        }
    }
}

// Admin console for broadcasting messages
void adminConsole(int udpSocket) {
    sleep(2); // Let server initialize
   
    cout << "\n========================================" << endl;
    cout << "     ADMIN CONSOLE - Central Server    " << endl;
    cout << "========================================" << endl;
   
    while (true) {
        cout << "\nAdmin Menu:" << endl;
        cout << "1. View Connected Campuses" << endl;
        cout << "2. Broadcast Announcement (UDP)" << endl;
        cout << "3. Exit" << endl;
        cout << "Choice: ";
       
        int choice;
        cin >> choice;
        cin.ignore();
       
        if (choice == 1) {
            lock_guard<mutex> lock(clientsMutex);
            cout << "\n----- Connected Campuses -----" << endl;
            if (connectedClients.empty()) {
                cout << "No campuses connected." << endl;
            } else {
                for (const auto& [campus, client] : connectedClients) {
                    cout << "Campus: " << campus
                         << " | Status: " << client.lastStatus
                         << " | Last Seen: " << (time(nullptr) - client.lastSeen) << "s ago" << endl;
                }
            }
            cout << "------------------------------" << endl;
        }
        else if (choice == 2) {
            cout << "Enter announcement message: ";
            string announcement;
            getline(cin, announcement);
           
            string broadcastMsg = "BROADCAST:" + announcement;
           
            lock_guard<mutex> lock(clientsMutex);
            for (const auto& [campus, client] : connectedClients) {
                if (client.udpPort > 0 && !client.ipAddress.empty()) {
                    struct sockaddr_in clientAddr;
                    clientAddr.sin_family = AF_INET;
                    clientAddr.sin_port = htons(client.udpPort);
                    inet_pton(AF_INET, client.ipAddress.c_str(), &clientAddr.sin_addr);
                   
                    sendto(udpSocket, broadcastMsg.c_str(), broadcastMsg.length(), 0,
                           (struct sockaddr*)&clientAddr, sizeof(clientAddr));
                }
            }
           
            cout << "Broadcast sent to all campuses." << endl;
        }
        else if (choice == 3) {
            cout << "Exiting admin console..." << endl;
            break;
        }
    }
}

int main() {
    // Create TCP socket
    int tcpSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (tcpSocket < 0) {
        cerr << "Failed to create TCP socket" << endl;
        return 1;
    }
   
    // Set socket options
    int opt = 1;
    setsockopt(tcpSocket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
   
    // Bind TCP socket
    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(TCP_PORT);
   
    if (bind(tcpSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        cerr << "TCP bind failed" << endl;
        return 1;
    }
   
    // Listen on TCP socket
    if (listen(tcpSocket, 10) < 0) {
        cerr << "Listen failed" << endl;
        return 1;
    }
   
    // Create UDP socket
    int udpSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (udpSocket < 0) {
        cerr << "Failed to create UDP socket" << endl;
        return 1;
    }
   
    // Bind UDP socket
    struct sockaddr_in udpAddr;
    udpAddr.sin_family = AF_INET;
    udpAddr.sin_addr.s_addr = INADDR_ANY;
    udpAddr.sin_port = htons(UDP_PORT);
   
    if (bind(udpSocket, (struct sockaddr*)&udpAddr, sizeof(udpAddr)) < 0) {
        cerr << "UDP bind failed" << endl;
        return 1;
    }
   
    cout << "========================================" << endl;
    cout << "  NU-Information Exchange System" << endl;
    cout << "       Central Server Started" << endl;
    cout << "========================================" << endl;
    cout << "TCP Port: " << TCP_PORT << endl;
    cout << "UDP Port: " << UDP_PORT << endl;
    cout << "Waiting for campus connections..." << endl;
    cout << "========================================\n" << endl;
   
    // Start UDP status handler thread
    thread udpThread(handleUDPStatus, udpSocket);
    udpThread.detach();
   
    // Start admin console thread
    thread adminThread(adminConsole, udpSocket);
    adminThread.detach();
   
    // Accept client connections
    while (true) {
        struct sockaddr_in clientAddr;
        socklen_t clientLen = sizeof(clientAddr);
       
        int clientSocket = accept(tcpSocket, (struct sockaddr*)&clientAddr, &clientLen);
        if (clientSocket < 0) {
            cerr << "Accept failed" << endl;
            continue;
        }
       
        // Receive authentication message
        char authBuffer[BUFFER_SIZE];
        memset(authBuffer, 0, BUFFER_SIZE);
        recv(clientSocket, authBuffer, BUFFER_SIZE - 1, 0);
       
        string campusName;
        if (authenticateClient(string(authBuffer), campusName)) {
            // Authentication successful
            string response = "AUTH_SUCCESS";
            send(clientSocket, response.c_str(), response.length(), 0);
           
            // Add to connected clients
            {
                lock_guard<mutex> lock(clientsMutex);
                connectedClients[campusName] = {clientSocket, campusName, "Online", time(nullptr), 0, ""};
            }
           
            safePrint("[SERVER] Campus " + campusName + " connected and authenticated.");
           
            // Handle client in a new thread
            thread clientThread(handleCampusClient, clientSocket, campusName);
            clientThread.detach();
        } else {
            // Authentication failed
            string response = "AUTH_FAILED";
            send(clientSocket, response.c_str(), response.length(), 0);
            close(clientSocket);
            safePrint("[SERVER] Authentication failed for a client.");
        }
    }
   
    close(tcpSocket);
    close(udpSocket);
    return 0;
}
